cp icon.png icon512.png
convert icon512.png -resize 50% icon256.png
convert icon256.png -resize 50% icon128.png
convert icon128.png -resize 50% icon64.png
convert icon64.png -resize 75% icon48.png
convert icon64.png -resize 50% icon32.png
convert icon32.png -resize 50% icon16.png