import dashboard.view.Main;
import javafx.application.Application;

/**
 * Launch the Ad Auction Dashboard
 */
public class Launcher {
	public static void main(String args[]) {
		// Launch the JavaFX application
		Application.launch(Main.class);
	}
}
