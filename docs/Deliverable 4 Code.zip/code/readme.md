Ad Auction Dashboard
====================

## Starting the Dashboard

Either double click the jar or use the command:

    java -jar increment3.jar

## Using the Dashboard

Once loaded, you will be presented with a Graph. You can now use the different
filters on the left to query, or use Graph Metrics to change graph.


